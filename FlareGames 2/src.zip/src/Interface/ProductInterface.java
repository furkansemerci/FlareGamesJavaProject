package Interface;


public interface ProductInterface {
	
	public abstract boolean eligibleForDiscount(int id);
	
}
