package ChildAndParentClasses;

public class GameProduct extends Product {

	private String supportedConsole;
	private String genre;
	private int year; 
	private String ageRating;
	
	
	public GameProduct(int id, int quantity, String name, double price, double shippingFee, boolean secondHand,
			boolean rentable, String supportedConsole, String genre, int year, String ageRating) {
		super(id, quantity, name, price, shippingFee, secondHand, rentable);
		this.supportedConsole = supportedConsole;
		this.genre = genre;
		this.year = year;
		this.ageRating = ageRating;
	}


	@Override
	public String toString() {
		return "Game Product Information:\n" + super.toString() + "Supported Console: " + supportedConsole + ", \nGenre: " + genre + ", \nYear: "
				+ year + ", \nAge Rating: " + ageRating;
	}


	public String getSupportedConsole() {
		return supportedConsole;
	}




	public void setSupportedConsole(String supportedConsole) {
		this.supportedConsole = supportedConsole;
	}




	public String getGenre() {
		return genre;
	}




	public void setGenre(String genre) {
		this.genre = genre;
	}




	public int getYear() {
		return year;
	}




	public void setYear(int year) {
		this.year = year;
	}




	public String getAgeRating() {
		return ageRating;
	}




	public void setAgeRating(String ageRating) {
		this.ageRating = ageRating;
	}
	
	
	
	
	
	
	
	
	
	
}
