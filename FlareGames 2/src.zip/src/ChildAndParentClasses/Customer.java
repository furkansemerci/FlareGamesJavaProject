package ChildAndParentClasses;

public class Customer {
	private String nameSurname;
	private String address;
	private int ItemId;
	
	public Customer(String nameSurname, String address, int ItemId) {
		this.nameSurname = nameSurname;
		this.address = address;
		this.ItemId = ItemId;
	}

	public String getNameSurname() {
		return nameSurname;
	}

	public void setNameSurname(String nameSurname) {
		this.nameSurname = nameSurname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getItemId() {
		return ItemId;
	}

	public void setItemId(int itemId) {
		ItemId = itemId;
	}

	@Override
	public String toString() {
		return "Customer \nName Surname: " + nameSurname + "\naddress: " + address + "ItemId:\n" + ItemId ;
		
	}
	
	
}
