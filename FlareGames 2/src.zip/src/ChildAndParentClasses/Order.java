package ChildAndParentClasses;

public class Order {
	private int orderId;
	private Product product = null;
	private Customer customer = null;
	private double shippingFee;
	
	Order(Product p, Order o)
	{
		product = p;
		customer = o;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public double getShippingFee() {
		return shippingFee;
	}

	public void setShippingFee(double shippingFee) {
		this.shippingFee = shippingFee;
	}

	@Override
	public String toString() {
		return "Order "
				+ "\n Order Id=" + orderId
				+ product.toString()
				+ customer.toString()
				+ "\nShipping Fee=" + shippingFee;
	}
	
	/*
	public void calculateShippingFee()
	{
		
	} 
	*/
	
}
