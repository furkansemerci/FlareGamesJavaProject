package ChildAndParentClasses;
import Interface.*;

public class Product implements ProductInterface{
	
	protected int id, quantity;
	protected String name;
	protected double price, shippingFee;
	protected boolean secondHand,rentable;
	protected static int numOfItems;
	
	
	public Product(int id, int quantity, String name, double price, double shippingFee, boolean secondHand,
			boolean rentable) {
		this.id = id;
		this.quantity = quantity;
		this.name = name;
		this.price = price;
		this.shippingFee = shippingFee;
		this.secondHand = secondHand;
		this.rentable = rentable;
	}
	
	


	public int getId() {
		return id;
	}




	public void setId(int id) {
		this.id = id;
	}




	public int getQuantity() {
		return quantity;
	}




	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public double getPrice() {
		return price;
	}




	public void setPrice(double price) {
		this.price = price;
	}




	public double getShippingFee() {
		return shippingFee;
	}




	public void setShippingFee(double shippingFee) {
		this.shippingFee = shippingFee;
	}




	public boolean isSecondHand() {
		return secondHand;
	}




	public void setSecondHand(boolean secondHand) {
		this.secondHand = secondHand;
	}




	public boolean isRentable() {
		return rentable;
	}




	public void setRentable(boolean rentable) {
		this.rentable = rentable;
	}




	public static int getNumOfItems() {
		return numOfItems;
	}




	public static void setNumOfItems(int numOfItems) {
		Product.numOfItems = numOfItems;
	}




	@Override
	public String toString() {
		String res = "";
		
		res+="Item ID: " + id + "Item Name : " + name + "\nQuantity: " + quantity + "\nPrice: "+
		"\nPrice: " + price + "\nStatus: ";
		
		if(secondHand)
			res += "Second Hand\n";
		
		else
			res += "New\n";
		
		res += "Rentability: ";
		
		if(!rentable)
			res += "Not ";
		
		res += "Rentable\n";
		
		res += "Shipping Fee: " + shippingFee + "\n"; 
		
		return res;
	}
	
	public boolean eligibleForDiscount(int id) {
				
		String str = "" + id;
		
		int initial = Integer.parseInt(str.substring(0, 1));
		
		if(initial == 1)
		 return true;
		
		return false;
		
	}

	
}
