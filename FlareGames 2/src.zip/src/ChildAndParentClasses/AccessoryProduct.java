package ChildAndParentClasses;


public class AccessoryProduct extends Product{
	
	private String type;
	private String brand;
	private boolean original;
	
	
	public AccessoryProduct(int id, int quantity, String name, double price, double shippingFee, boolean secondHand,
			boolean rentable, String type, String brand, boolean original) {
		super(id, quantity, name, price, shippingFee, secondHand, rentable);
		this.type = type;
		this.brand = brand;
		this.original = original;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public boolean isOriginal() {
		return original;
	}

	public void setOriginal(boolean original) {
		this.original = original;
	}
	
	@Override
	public String toString() {
		String yn = "";
		if (original==true) {
			yn="It is orginal accessory product";
		}
		else {
			yn="It is nat original product";
		}
		return super.toString()
				+ "\nType=" + type 
				+ "\nBrand=" + brand 
				+ "\nOriginal=" + yn + "\n";
	}
	
}
