package hasAClasses;

public class Customer {
	private String nameSurname;
	private String address;
	private int id;
	
	Customer(String name, String address, int id)
	{
		this.nameSurname=name;
		this.address=address;
		this.id=id;
	}

	public String getNameSurname() {
		return nameSurname;
	}

	public void setNameSurname(String nameSurname) {
		this.nameSurname = nameSurname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Customer "
				+ "\nName and Surname=" + nameSurname
				+ "\nAddress=" + address 
				+ "\nId=" + id + "\n";
	}
}
