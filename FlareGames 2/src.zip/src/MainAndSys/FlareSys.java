package MainAndSys;

import java.util.ArrayList;

import ChildAndParentClasses.Product;

public class FlareSys {
	private static ArrayList<Product> stock = new ArrayList<Product>();
	private static ArrayList<Order> orders = new ArrayList<Order>();
	
	
	public static boolean doesProductExist(int id) {
		for(Product p: stock) {
			if(p.getId() == id)
				return false;
		}
		
		return true;
	}
	
	public static boolean doesOrderExist(int id) {
		for(Order o: orders) {
			if(o.getId() == id)
				return false;
		}
		return true;
	}
	
	public static boolean addStock(Product p) {
		if(doesProductExist(p.getId())) {
			return false;
		}
		else {
			stock.add(p);
			return true;
			
		}
		
	}
	
	public static boolean addOrder(Order o) {
		if(doesOrderExist(o.getId())) {
			return false;
		}
		else {
			order.add(o);
			return true;
			
		}
	}
	
	public static boolean removeProduct(int id) {
		for(int i= 0 ;i < stock.size();i++) {
			if(stock.get(i).getId() == id) {
				
				stock.remove(i);
				return true;
			}
			
		}
		return false;
	}
	
	public static Product findProductByID(int id) {
		for(Product p: stock) {
			if(p.getId() == id) {
				return p;
			}
		}
		return null;
	}
	
	
	public static double calculateTotalPrice() { //BAKILACAK
		double total = 0.0;
		for(Product p: stock) {
			total += p.getPrice();
		}
		return total;
	}
	
	public static String displayStock() {
		String output = "";
		
		for(Product p : stock) {
			output += p.toString();
		}
		
		return output;
	}
	
	public static String displayOrder() {
		String output = "";
		
		for(Order o : orders) {
			output += o.toString();
		}
		
		return output;
	}
	
	
	public static boolean updateStock(Product replaced, Product replacing) {
		try {
	        int index = stock.indexOf(replaced);
	        if (index == -1) {
	            return false;
	        }
	        stock.set(index, replacing);
	        return true;
	    } catch (Exception e) {
	        e.printStackTrace(); 
	        return false; 
	    }
		
	}
	
	public static boolean updateOrder(Order replaced, Order replacing) {
		try {
	        int index = orders.indexOf(replaced);
	        if (index == -1) {
	            return false;
	        }
	        orders.set(index, replacing);
	        return true;
	    } catch (Exception e) {
	        e.printStackTrace(); 
	        return false; 
	    }
	}
	
	
}
