package GUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JSpinner;

public class addProduct extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField ProductNameField;
	private JTextField idField;
	private JTextField txtSex;
	
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public addProduct() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 537, 484);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		ProductNameField = new JTextField();
		ProductNameField.setBounds(137, 23, 130, 26);
		contentPane.add(ProductNameField);
		ProductNameField.setColumns(10);
		
		JLabel ProductNameLabel = new JLabel("Product Name:");
		ProductNameLabel.setBounds(28, 28, 124, 16);
		contentPane.add(ProductNameLabel);
		
		JLabel QuantityLabel = new JLabel("Quantity:");
		QuantityLabel.setBounds(28, 61, 73, 16);
		contentPane.add(QuantityLabel);
		
		JLabel idLabel = new JLabel("ID:");
		idLabel.setBounds(28, 89, 73, 16);
		contentPane.add(idLabel);
		
		idField = new JTextField();
		idField.setBounds(137, 84, 130, 26);
		contentPane.add(idField);
		idField.setColumns(10);
		
		JSpinner quantitySelector = new JSpinner();
		quantitySelector.setBounds(133, 56, 34, 26);
		contentPane.add(quantitySelector);
		
		JLabel PriceLabel = new JLabel("Price Per Quantity:");
		PriceLabel.setBounds(28, 117, 124, 16);
		contentPane.add(PriceLabel);
		
		txtSex = new JTextField();
		txtSex.setBounds(147, 112, 130, 26);
		contentPane.add(txtSex);
		txtSex.setColumns(10);
	}
}
